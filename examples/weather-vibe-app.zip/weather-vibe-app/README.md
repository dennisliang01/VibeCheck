# 🌐 WEATHER.TERMINAL v2.0

A **vibe-coded** cyberpunk weather application with real-time atmospheric data display.

![Version](https://img.shields.io/badge/version-2.0.1-00ff41)
![License](https://img.shields.io/badge/license-MIT-00d9ff)
![Status](https://img.shields.io/badge/status-ONLINE-00ff41)

## ⚡ Features

### 🎨 Visual Design
- **Retro-Futuristic Cyberpunk Aesthetic** with neon green, blue, and pink color scheme
- **Animated Grid Background** with infinite scroll effect
- **CRT Scanline Overlay** for authentic terminal feel
- **Floating Particles** system for dynamic backgrounds
- **Custom Neon Cursor** that changes on hover
- **Glitch Effects** and smooth animations throughout

### 🌤️ Weather Features
- Real-time weather data from OpenWeatherMap API
- Current conditions with temperature, humidity, pressure, wind speed
- 5-day weather forecast with daily breakdowns
- Sunrise/sunset times
- Wind direction with compass readings
- Cloud coverage and visibility data
- **Demo mode** with mock data (works without API key)

### ⚙️ Technical Features
- **Component-Based Architecture** with separate modules
- **Modular CSS** with variables, animations, and responsive design
- **Keyboard Shortcuts** for power users
- **Local Storage** for remembering last searched city
- **Auto-refresh** capability (optional)
- **Error Handling** with user-friendly messages
- **Fully Responsive** - works on desktop, tablet, and mobile

## 📁 Project Structure

```
weather-vibe-app/
├── index.html              # Main HTML entry point
├── css/
│   ├── variables.css       # CSS custom properties & theme colors
│   ├── base.css           # Resets, global styles, backgrounds
│   ├── animations.css     # Keyframe animations & effects
│   ├── components.css     # Reusable UI components
│   ├── weather.css        # Weather-specific styles
│   └── responsive.css     # Mobile & tablet breakpoints
├── js/
│   ├── config.js          # App configuration & API keys
│   ├── utils.js           # Utility functions & helpers
│   ├── api.js             # Weather API service layer
│   ├── components.js      # UI component builders
│   ├── weather.js         # Weather data logic
│   ├── animations.js      # Visual effects & animations
│   └── app.js             # Main application entry point
└── README.md              # This file
```

## 🚀 Quick Start

### Option 1: Demo Mode (No API Key Required)
1. Open `index.html` in your browser
2. The app will run in demo mode with mock weather data
3. Search for any city and see simulated weather

### Option 2: Live Data (With API Key)
1. Get a **free API key** from [OpenWeatherMap](https://openweathermap.org/api)
2. Open `js/config.js`
3. Replace `YOUR_API_KEY_HERE` with your actual API key:
   ```javascript
   API_KEY: 'your_actual_api_key_here'
   ```
4. Set `USE_MOCK_DATA: false` in the config
5. Open `index.html` in your browser

## ⌨️ Keyboard Shortcuts

- **Ctrl/Cmd + K** - Focus search input
- **Ctrl/Cmd + R** - Refresh current weather
- **Ctrl/Cmd + L** - Get weather for your location
- **Enter** - Search for city (when input focused)
- **Escape** - Clear search input

## 🎮 Console Commands

Open your browser's developer console and try these commands:

```javascript
debug()     // Show system information
status()    // Get current app status
refresh()   // Refresh weather data
theme()     // Toggle light/dark theme
```

## 🔧 Configuration

Edit `js/config.js` to customize:

```javascript
const CONFIG = {
    API_KEY: 'YOUR_API_KEY_HERE',
    DEFAULT_CITY: 'Tokyo',
    UNITS: 'metric', // or 'imperial'
    QUICK_CITIES: ['Tokyo', 'New York', 'London', ...],
    PARTICLE_COUNT: 30,
    ENABLE_FORECAST: true,
    ENABLE_PARTICLES: true,
    ENABLE_AUTO_REFRESH: false
};
```

## 📱 Responsive Design

The app is fully responsive with breakpoints at:
- **Desktop**: 1920px+ (large screens)
- **Laptop**: 1024px - 1919px
- **Tablet**: 768px - 1023px
- **Mobile**: 480px - 767px
- **Small Mobile**: < 480px

## 🎨 Customization

### Colors
Edit `css/variables.css` to change the color scheme:
```css
:root {
    --neon-green: #00ff41;
    --neon-blue: #00d9ff;
    --neon-pink: #ff006e;
    /* ... more colors */
}
```

### Fonts
The app uses:
- **VT323** - Terminal-style monospace
- **Orbitron** - Futuristic display font
- **Space Mono** - Modern monospace

Change fonts in `css/variables.css`:
```css
:root {
    --font-terminal: 'VT323', monospace;
    --font-display: 'Orbitron', monospace;
    --font-mono: 'Space Mono', monospace;
}
```

## 🏗️ Architecture

### Module Overview

**Config** (`config.js`)
- Application settings
- API configuration
- Feature flags

**Utils** (`utils.js`)
- Helper functions
- Date/time formatting
- Storage management

**API** (`api.js`)
- Weather data fetching
- Mock data generation
- Geolocation services

**Components** (`components.js`)
- UI component builders
- HTML template generation
- Reusable elements

**Weather** (`weather.js`)
- Main weather logic
- Search functionality
- Data display

**Animations** (`animations.js`)
- Visual effects
- Particle system
- Animation helpers

**App** (`app.js`)
- Application initialization
- Event coordination
- System management

## 🐛 Troubleshooting

**Weather data not loading?**
- Check if API key is set correctly in `js/config.js`
- Make sure `USE_MOCK_DATA` is set to `false`
- Check browser console for errors

**Animations not working?**
- Check if browser supports CSS animations
- Try disabling browser extensions
- Make sure JavaScript is enabled

**Quick city buttons not responding?**
- Clear browser cache
- Reload the page
- Check console for errors

## 🎯 Browser Support

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ⚠️ IE11 (limited support)

## 📄 License

MIT License - feel free to use this project for learning or personal use!

## 🙏 Credits

- Weather data provided by [OpenWeatherMap](https://openweathermap.org/)
- Fonts from [Google Fonts](https://fonts.google.com/)
- Built with vanilla JavaScript, HTML, and CSS

## 🔮 Easter Eggs

Try the Konami code: ⬆️⬆️⬇️⬇️⬅️➡️⬅️➡️BA

---

**Made with 💚 and cyberpunk vibes**

For questions or issues, check the browser console for debug info!
