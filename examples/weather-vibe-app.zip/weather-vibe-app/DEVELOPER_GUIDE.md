# 🎯 DEVELOPER GUIDE - Understanding Vibe-Coded Architecture

## What is "Vibe Coding"?

**Vibe coding** is an approach to web development that prioritizes:
1. **Strong aesthetic identity** - Clear visual theme with personality
2. **Component separation** - Modular, organized file structure
3. **Attention to detail** - Animations, effects, micro-interactions
4. **User experience** - Smooth transitions, feedback, responsive design
5. **Code quality** - Clean, commented, maintainable architecture

This project demonstrates vibe coding through its cyberpunk aesthetic and modular architecture.

---

## 📂 Architecture Deep Dive

### 1. CSS Architecture (6 Files)

#### `variables.css` - Design Tokens
**Purpose**: Single source of truth for all design values
**Key Concepts**:
- CSS Custom Properties for theme colors
- Spacing scale (xs, sm, md, lg, xl, 2xl)
- Typography system
- Z-index layers
- Transition timings

**Why?**: Consistency across the app. Change one variable, update everywhere.

```css
:root {
    --neon-green: #00ff41;
    --space-md: 1rem;
    --transition-normal: 0.3s ease;
}
```

#### `base.css` - Foundation
**Purpose**: Reset styles, global elements, background effects
**Key Concepts**:
- Box-sizing reset
- Custom scrollbar styling
- Background grid/scanline layers (position: fixed)
- Custom cursor using SVG data URIs
- Selection colors

**Why?**: Establishes baseline styling before components.

#### `animations.css` - Motion Library
**Purpose**: All @keyframes animations in one place
**Key Concepts**:
- Reusable keyframe animations
- Stagger classes for sequential animations
- Various effects (glitch, pulse, float, shimmer)

**Why?**: Centralized animation definitions prevent duplication.

#### `components.css` - UI Building Blocks
**Purpose**: Styles for reusable UI components
**Key Concepts**:
- Panel system (header, body, controls)
- Button variants (primary, secondary, small)
- Input styling
- Loading/error states
- Footer components

**Why?**: Modular components can be reused across the app.

#### `weather.css` - Domain-Specific Styles
**Purpose**: Weather display specific styling
**Key Concepts**:
- Weather card layouts
- Stat grids
- Forecast cards
- Temperature displays

**Why?**: Separates weather-specific UI from general components.

#### `responsive.css` - Adaptive Design
**Purpose**: Media queries for different screen sizes
**Key Concepts**:
- Breakpoints (768px, 480px, 1920px)
- Mobile-first adjustments
- Print styles
- Reduced motion support
- High contrast mode

**Why?**: Keeps responsive logic separate and organized.

---

### 2. JavaScript Architecture (7 Files)

#### `config.js` - Configuration
**Purpose**: Single source for all app settings
**Exports**: `window.APP_CONFIG`

**Key Concepts**:
```javascript
const CONFIG = {
    API_KEY: 'YOUR_API_KEY_HERE',
    DEFAULT_CITY: 'Tokyo',
    QUICK_CITIES: [...],
    PARTICLE_COUNT: 30,
    USE_MOCK_DATA: true
};
```

**Why?**: Easy to configure without diving into code. Feature flags for toggling functionality.

#### `utils.js` - Utility Functions
**Purpose**: Reusable helper functions
**Exports**: `window.Utils`

**Key Concepts**:
- Date/time formatting
- Temperature conversion
- Local storage wrapper
- Debounce function
- Animation helpers

**Why?**: DRY principle - write once, use everywhere.

```javascript
Utils.formatTime(timestamp, 'full')
Utils.storage.set('key', value)
Utils.debounce(fn, 300)
```

#### `api.js` - Data Layer
**Purpose**: All weather API interactions
**Exports**: `window.WeatherAPI`

**Key Concepts**:
- Async/await for API calls
- Error handling with try/catch
- Mock data for demo mode
- Response normalization

**Why?**: Separates data fetching from UI logic. Easy to swap APIs or add caching.

```javascript
const result = await WeatherAPI.fetchWeather(city);
if (result.success) {
    // Use result.data
}
```

#### `components.js` - Template Builders
**Purpose**: Generate HTML for UI components
**Exports**: `window.Components`

**Key Concepts**:
- Template literal strings
- Component functions return HTML
- Data-driven rendering
- Separation of structure and behavior

**Why?**: Keeps HTML generation separate from logic. Easy to modify UI structure.

```javascript
Components.weatherDisplay(data)  // Returns HTML string
Components.loading()              // Returns loading HTML
Components.error(message)         // Returns error HTML
```

#### `weather.js` - Business Logic
**Purpose**: Weather-specific application logic
**Exports**: `window.Weather`

**Key Concepts**:
- Event listener attachment
- Search functionality
- Display orchestration
- State management (currentCity)
- Local storage integration

**Why?**: Core weather functionality in one module. Easy to test and maintain.

```javascript
Weather.search(city)      // Search and display
Weather.refresh()         // Refresh current
Weather.currentCity       // Current state
```

#### `animations.js` - Visual Effects
**Purpose**: Particle system and animation effects
**Exports**: `window.Animations`

**Key Concepts**:
- Particle generation with random properties
- CSS variable manipulation
- Timestamp/uptime counters
- Intersection Observer for scroll animations
- Effect functions (glitch, pulse, shake)

**Why?**: Centralizes all animation logic. Effects can be triggered programmatically.

```javascript
Animations.createParticles()
Animations.glitch(element, duration)
Animations.neonPulse(element, color)
```

#### `app.js` - Application Core
**Purpose**: Initialize and coordinate all modules
**Exports**: `window.App`

**Key Concepts**:
- Module initialization sequence
- Keyboard shortcut registration
- Theme management
- Error handling
- Debug utilities
- Easter eggs

**Why?**: Single entry point. Controls app lifecycle and module coordination.

```javascript
App.init()              // Start everything
App.getStatus()         // System info
App.debug()             // Debug console
```

---

## 🔄 Data Flow

```
User Input (index.html)
    ↓
Event Listeners (weather.js)
    ↓
API Call (api.js)
    ↓
Data Processing (utils.js)
    ↓
Component Generation (components.js)
    ↓
DOM Update (weather.js)
    ↓
CSS Animations (animations.css)
```

---

## 🎨 Styling Methodology

### Layered Approach
1. **Variables** - Design tokens
2. **Base** - Resets and globals
3. **Components** - Reusable UI elements
4. **Domain** - Feature-specific styles
5. **Responsive** - Adaptive overrides

### Naming Conventions
- **BEM-inspired** for components: `.panel-header`, `.stat-card-value`
- **Utility classes**: `.hidden`, `.fade-in`, `.text-center`
- **State classes**: `.active`, `.loading`, `.error`

### Color System
- **Primary**: Neon green (#00ff41) - Terminal text, borders
- **Secondary**: Neon blue (#00d9ff) - Interactive elements
- **Accent**: Neon pink (#ff006e) - Errors, highlights
- **Background**: Dark blues (#0a0e27, #050814) - Panels, base

---

## 🧩 Component Patterns

### Panel Component Structure
```html
<div class="panel">
    <div class="panel-header">
        <div class="panel-title">...</div>
        <div class="panel-controls">...</div>
    </div>
    <div class="panel-body">
        <!-- Content -->
    </div>
</div>
```

### Stat Card Pattern
```html
<div class="stat-card">
    <div class="stat-card-icon">🌡️</div>
    <div class="stat-card-label">Temperature</div>
    <div class="stat-card-value">25°C</div>
</div>
```

---

## 🔌 Module Communication

### Global Exports
All modules export to `window`:
```javascript
window.APP_CONFIG   // Configuration
window.Utils        // Utilities
window.WeatherAPI   // API layer
window.Components   // Templates
window.Weather      // Weather logic
window.Animations   // Effects
window.App          // Main app
```

### Why Global?
- Simple inter-module communication
- Console accessibility for debugging
- No build step required
- Easy to understand for learners

### Alternative (ES6 Modules)
For production, could refactor to:
```javascript
// utils.js
export const Utils = { ... }

// app.js
import { Utils } from './utils.js'
```

---

## ⚡ Performance Considerations

### CSS
- Use `transform` and `opacity` for animations (GPU accelerated)
- `will-change` for frequently animated elements
- Fixed position backgrounds prevent reflow

### JavaScript
- Debounced search input
- Lazy loading of forecast data
- Local storage caching
- IntersectionObserver for scroll animations (efficient)

### Network
- Single API call per search
- Optional auto-refresh (disabled by default)
- Mock data mode for zero network usage

---

## 🧪 Testing Approach

### Manual Testing
1. **Search functionality**: Try various cities
2. **Responsive design**: Test different screen sizes
3. **Keyboard shortcuts**: Verify all shortcuts work
4. **Error handling**: Try invalid cities
5. **Theme toggle**: Switch themes

### Console Testing
```javascript
// Get system status
status()

// Force refresh
refresh()

// Enable debug mode
debug()

// Test API directly
WeatherAPI.fetchWeather('London').then(console.log)

// Test components
document.body.innerHTML = Components.loading()
```

---

## 🎓 Learning Exercises

### Beginner
1. Change color scheme in `variables.css`
2. Add a new quick city button
3. Modify temperature unit (C/F)
4. Change default city

### Intermediate
1. Add new weather stat (UV index, dew point)
2. Create custom animation in `animations.css`
3. Add hourly forecast display
4. Implement theme switcher UI

### Advanced
1. Add multiple API support (fallback APIs)
2. Implement weather alerts system
3. Add data visualization (charts)
4. Create PWA with offline support
5. Add unit testing

---

## 📚 Key Concepts Demonstrated

### Separation of Concerns
- **HTML**: Structure (index.html)
- **CSS**: Presentation (6 CSS files)
- **JavaScript**: Behavior (7 JS files)

### Modular Architecture
- Each file has single responsibility
- Clear dependencies
- Easy to locate code

### Progressive Enhancement
- Works without JavaScript (shows HTML)
- Works without API key (mock data)
- Works on all screen sizes

### User Experience
- Loading states
- Error handling
- Keyboard shortcuts
- Smooth animations
- Responsive feedback

---

## 🔧 Extending the App

### Adding New Features

**1. Add a new weather stat:**
```javascript
// In components.js
<div class="stat-card">
    <div class="stat-card-icon">☁️</div>
    <div class="stat-card-label">UV Index</div>
    <div class="stat-card-value">${data.uv}</div>
</div>
```

**2. Add new animation:**
```css
/* In animations.css */
@keyframes myAnimation {
    0% { transform: scale(1); }
    50% { transform: scale(1.2); }
    100% { transform: scale(1); }
}
```

**3. Add new API endpoint:**
```javascript
// In api.js
fetchAirQuality: async (city) => {
    // Implementation
}
```

---

## 💡 Best Practices Used

1. ✅ **DRY**: Utility functions prevent repetition
2. ✅ **Single Responsibility**: Each module does one thing
3. ✅ **Configuration**: Settings separated from code
4. ✅ **Error Handling**: Try/catch and user feedback
5. ✅ **Comments**: Clear documentation
6. ✅ **Naming**: Descriptive variable/function names
7. ✅ **Consistency**: Unified code style
8. ✅ **Accessibility**: Keyboard navigation, contrast
9. ✅ **Performance**: Optimized animations, caching
10. ✅ **Maintainability**: Clear structure, modularity

---

## 🎯 Understanding "Vibe" Elements

### What Makes It "Vibe-Coded"?

**1. Strong Visual Identity**
- Consistent cyberpunk theme
- Custom cursor
- Neon glow effects
- Terminal aesthetic

**2. Attention to Detail**
- Pulsing status dots
- Scanline overlay
- Floating particles
- Smooth transitions

**3. User Delight**
- Easter eggs (Konami code)
- Console commands
- Loading states
- Hover effects

**4. Professional Structure**
- Modular architecture
- Clean code
- Documentation
- Configuration

**5. Polish**
- Responsive design
- Error handling
- Keyboard shortcuts
- Theme support

---

This is **vibe coding**: combining strong aesthetics with solid engineering.

Happy coding! 🚀
