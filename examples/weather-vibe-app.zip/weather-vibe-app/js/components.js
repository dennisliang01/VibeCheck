// ============================================
// COMPONENTS - UI Component Builders
// ============================================

const Components = {
    /**
     * Create loading component
     */
    loading: () => {
        return `
            <div class="panel">
                <div class="panel-header">
                    <div class="panel-title">
                        <span class="panel-icon">⚡</span>
                        <span>SYSTEM.PROCESSING</span>
                    </div>
                    <div class="panel-controls">
                        <div class="control-dot red"></div>
                        <div class="control-dot yellow"></div>
                        <div class="control-dot green"></div>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="loading">FETCHING ATMOSPHERIC DATA</div>
                </div>
            </div>
        `;
    },

    /**
     * Create error component
     */
    error: (message) => {
        return `
            <div class="panel">
                <div class="panel-header">
                    <div class="panel-title">
                        <span class="panel-icon">⚠️</span>
                        <span>ERROR.REPORT</span>
                    </div>
                    <div class="panel-controls">
                        <div class="control-dot red"></div>
                        <div class="control-dot yellow"></div>
                        <div class="control-dot green"></div>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="error">
                        <div class="error-title">⚠️ SYSTEM ERROR ⚠️</div>
                        <div>${message}</div>
                        ${window.APP_CONFIG.USE_MOCK_DATA ? `
                            <div style="opacity: 0.7; margin-top: 1rem; font-size: 1rem;">
                                💡 TIP: Get a free API key from <a href="https://openweathermap.org" target="_blank" style="color: var(--neon-blue);">openweathermap.org</a><br>
                                and replace 'YOUR_API_KEY_HERE' in js/config.js
                            </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    },

    /**
     * Create weather display component
     */
    weatherDisplay: (data) => {
        const icon = Utils.getWeatherIcon(data.weather[0].main);
        const temp = Math.round(data.main.temp);
        const feelsLike = Math.round(data.main.feels_like);
        const windDirection = Utils.degToCompass(data.wind.deg || 0);
        
        return `
            <div class="weather-container active">
                <div class="panel">
                    <div class="panel-header">
                        <div class="panel-title">
                            <span class="panel-icon">🌍</span>
                            <span>WEATHER.DATA.OUTPUT</span>
                        </div>
                        <div class="panel-controls">
                            <div class="control-dot red"></div>
                            <div class="control-dot yellow"></div>
                            <div class="control-dot green"></div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="weather-main">
                            <div class="weather-left">
                                <div class="location">${data.name}, ${data.sys.country}</div>
                                <div class="temp-display">${temp}°C</div>
                                <div class="condition">${data.weather[0].main}</div>
                                <div class="condition-description">${data.weather[0].description}</div>
                            </div>
                            <div class="weather-right">
                                <div class="weather-icon-large">${icon}</div>
                            </div>
                        </div>

                        <div class="ascii-divider">
═══════════════════════════════════════════════════════════════════════════════
                        </div>

                        <div class="weather-stats">
                            <div class="stat-card">
                                <div class="stat-card-icon">${Utils.getStatIcon('feels_like')}</div>
                                <div class="stat-card-label">Feels Like</div>
                                <div class="stat-card-value">${feelsLike}°C</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-card-icon">${Utils.getStatIcon('humidity')}</div>
                                <div class="stat-card-label">Humidity</div>
                                <div class="stat-card-value">${data.main.humidity}%</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-card-icon">${Utils.getStatIcon('pressure')}</div>
                                <div class="stat-card-label">Pressure</div>
                                <div class="stat-card-value">${data.main.pressure} hPa</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-card-icon">${Utils.getStatIcon('wind')}</div>
                                <div class="stat-card-label">Wind Speed</div>
                                <div class="stat-card-value">${data.wind.speed} m/s</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-card-icon">${Utils.getStatIcon('visibility')}</div>
                                <div class="stat-card-label">Visibility</div>
                                <div class="stat-card-value">${(data.visibility / 1000).toFixed(1)} km</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-card-icon">${Utils.getStatIcon('status')}</div>
                                <div class="stat-card-label">Status</div>
                                <div class="stat-card-value" style="font-size: 1.5rem; color: var(--neon-green);">ONLINE</div>
                            </div>
                        </div>

                        <div class="additional-info">
                            <div class="info-section">
                                <div class="info-title">☀️ SUN DATA</div>
                                <div class="info-items">
                                    <div class="info-item">
                                        <span class="info-label">Sunrise</span>
                                        <span class="info-value">${Utils.formatTime(data.sys.sunrise, 'time')}</span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label">Sunset</span>
                                        <span class="info-value">${Utils.formatTime(data.sys.sunset, 'time')}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="info-section">
                                <div class="info-title">💨 WIND DATA</div>
                                <div class="info-items">
                                    <div class="info-item">
                                        <span class="info-label">Direction</span>
                                        <span class="info-value">${windDirection} (${data.wind.deg || 0}°)</span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label">Cloud Cover</span>
                                        <span class="info-value">${data.clouds.all}%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    /**
     * Create forecast component
     */
    forecastDisplay: (data) => {
        if (!data || !data.list) return '';
        
        // Get one forecast per day (at noon)
        const dailyForecasts = {};
        data.list.forEach(item => {
            const date = new Date(item.dt * 1000);
            const dateKey = date.toDateString();
            
            if (!dailyForecasts[dateKey]) {
                dailyForecasts[dateKey] = item;
            }
        });
        
        const forecasts = Object.values(dailyForecasts).slice(0, 5);
        
        const forecastCards = forecasts.map(forecast => {
            const icon = Utils.getWeatherIcon(forecast.weather[0].main);
            const temp = Math.round(forecast.main.temp);
            const tempMin = Math.round(forecast.main.temp_min);
            const tempMax = Math.round(forecast.main.temp_max);
            const day = Utils.formatTime(forecast.dt, 'date');
            
            return `
                <div class="forecast-card">
                    <div class="forecast-day">${day}</div>
                    <div class="forecast-icon">${icon}</div>
                    <div class="forecast-temp">${temp}°C</div>
                    <div class="forecast-temp-range">${tempMin}° / ${tempMax}°</div>
                    <div class="forecast-condition">${forecast.weather[0].description}</div>
                </div>
            `;
        }).join('');
        
        return `
            <div class="forecast-container">
                <div class="panel">
                    <div class="panel-header">
                        <div class="panel-title">
                            <span class="panel-icon">📅</span>
                            <span>FORECAST.DATA</span>
                        </div>
                        <div class="panel-controls">
                            <div class="control-dot red"></div>
                            <div class="control-dot yellow"></div>
                            <div class="control-dot green"></div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="forecast-grid">
                            ${forecastCards}
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    /**
     * Create quick city buttons
     */
    quickCityButtons: (cities) => {
        return cities.map(city => `
            <button class="quick-city" data-city="${city}">${city.toUpperCase()}</button>
        `).join('');
    }
};

// Export to global scope
window.Components = Components;
