// ============================================
// APP - Main Application Entry Point
// ============================================

/**
 * Weather Terminal Application
 * A cyberpunk-themed weather app with real-time data
 */

const App = {
    version: '2.0.1',
    initialized: false,

    /**
     * Initialize the application
     */
    init: () => {
        console.log('%c╔═══════════════════════════════════════════════╗', 'color: #00ff41');
        console.log('%c║   WEATHER.TERMINAL v' + App.version + '                  ║', 'color: #00ff41');
        console.log('%c║   Cyberpunk Weather Interface                ║', 'color: #00ff41');
        console.log('%c╚═══════════════════════════════════════════════╝', 'color: #00ff41');
        console.log('%c⚡ System initializing...', 'color: #00d9ff; font-weight: bold');
        
        // Check if already initialized
        if (App.initialized) {
            console.warn('App already initialized');
            return;
        }

        // Initialize modules in sequence
        try {
            App.initQuickCities();
            Animations.init();
            Weather.init();
            App.initKeyboardShortcuts();
            App.initTheme();
            
            if (window.APP_CONFIG.ENABLE_AUTO_REFRESH) {
                Weather.startAutoRefresh();
            }
            
            App.initialized = true;
            console.log('%c✅ System online - All modules loaded', 'color: #00ff41; font-weight: bold');
            
        } catch (error) {
            console.error('%c❌ System error during initialization:', 'color: #ff006e; font-weight: bold', error);
            App.handleInitError(error);
        }
    },

    /**
     * Initialize quick city buttons
     */
    initQuickCities: () => {
        const container = document.getElementById('quickCities');
        if (!container) return;
        
        const cities = window.APP_CONFIG.QUICK_CITIES;
        container.innerHTML = Components.quickCityButtons(cities);
    },

    /**
     * Initialize keyboard shortcuts
     */
    initKeyboardShortcuts: () => {
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + K: Focus search
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                document.getElementById('cityInput').focus();
            }
            
            // Ctrl/Cmd + R: Refresh weather
            if ((e.ctrlKey || e.metaKey) && e.key === 'r') {
                e.preventDefault();
                Weather.refresh();
            }
            
            // Ctrl/Cmd + L: Get location
            if ((e.ctrlKey || e.metaKey) && e.key === 'l') {
                e.preventDefault();
                Weather.searchByLocation();
            }
            
            // Escape: Clear search
            if (e.key === 'Escape') {
                document.getElementById('cityInput').value = '';
                document.getElementById('cityInput').blur();
            }
        });
        
        console.log('%c⌨️  Keyboard shortcuts enabled:', 'color: #00d9ff');
        console.log('  Ctrl/Cmd + K: Focus search');
        console.log('  Ctrl/Cmd + R: Refresh weather');
        console.log('  Ctrl/Cmd + L: Get location');
        console.log('  Escape: Clear search');
    },

    /**
     * Initialize theme
     */
    initTheme: () => {
        const savedTheme = Utils.storage.get('theme') || 'dark';
        document.documentElement.setAttribute('data-theme', savedTheme);
    },

    /**
     * Toggle theme
     */
    toggleTheme: () => {
        const current = document.documentElement.getAttribute('data-theme');
        const newTheme = current === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        Utils.storage.set('theme', newTheme);
        
        console.log(`Theme switched to: ${newTheme}`);
    },

    /**
     * Handle initialization errors
     */
    handleInitError: (error) => {
        const weatherDisplay = document.getElementById('weatherDisplay');
        if (weatherDisplay) {
            weatherDisplay.innerHTML = Components.error(
                `Failed to initialize application: ${error.message}`
            );
        }
    },

    /**
     * Get system status
     */
    getStatus: () => {
        return {
            version: App.version,
            initialized: App.initialized,
            currentCity: Weather.currentCity,
            config: window.APP_CONFIG,
            uptime: Utils.calculateUptime(Animations.startTime),
            particleCount: Animations.particleCount
        };
    },

    /**
     * Debug mode
     */
    debug: () => {
        console.log('%c═══ DEBUG INFO ═══', 'color: #ff006e; font-size: 16px; font-weight: bold');
        console.table(App.getStatus());
        console.log('Config:', window.APP_CONFIG);
        console.log('Utils:', window.Utils);
        console.log('Weather API:', window.WeatherAPI);
        console.log('Components:', window.Components);
        console.log('%c═════════════════', 'color: #ff006e; font-size: 16px; font-weight: bold');
    },

    /**
     * Easter egg - Konami code
     */
    initEasterEgg: () => {
        const konamiCode = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a'];
        let konamiIndex = 0;
        
        document.addEventListener('keydown', (e) => {
            if (e.key === konamiCode[konamiIndex]) {
                konamiIndex++;
                
                if (konamiIndex === konamiCode.length) {
                    App.easterEgg();
                    konamiIndex = 0;
                }
            } else {
                konamiIndex = 0;
            }
        });
    },

    /**
     * Easter egg activation
     */
    easterEgg: () => {
        console.log('%c🎉 EASTER EGG ACTIVATED!', 'color: #ff006e; font-size: 20px; font-weight: bold');
        
        // Glitch the title
        const title = document.querySelector('.main-title');
        if (title) {
            Animations.glitch(title, 2000);
        }
        
        // Extra particles
        if (Animations.particlesEnabled) {
            Animations.createParticles();
        }
        
        Utils.notify('🎮 CHEAT CODE ACTIVATED!', 'success');
    }
};

// Initialize app when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', App.init);
} else {
    App.init();
}

// Initialize easter egg
App.initEasterEgg();

// Export to global scope for console access
window.App = App;

// Expose helper functions to console
window.debug = App.debug;
window.status = App.getStatus;
window.refresh = Weather.refresh;
window.theme = App.toggleTheme;

console.log('%c💡 TIP: Type "debug()" in console for system info', 'color: #00d9ff; font-style: italic');
console.log('%c💡 TIP: Type "status()" for current status', 'color: #00d9ff; font-style: italic');
console.log('%c💡 TIP: Type "theme()" to toggle theme', 'color: #00d9ff; font-style: italic');
