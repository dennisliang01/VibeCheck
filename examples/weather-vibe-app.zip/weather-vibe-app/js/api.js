// ============================================
// API - Weather Data Service
// ============================================

const WeatherAPI = {
    /**
     * Fetch current weather data
     */
    fetchWeather: async (city) => {
        const config = window.APP_CONFIG;
        
        // Use mock data if enabled or API key not set
        if (config.USE_MOCK_DATA || config.API_KEY === 'YOUR_API_KEY_HERE') {
            return WeatherAPI.getMockWeather(city);
        }
        
        try {
            const url = `${config.API_BASE_URL}/weather?q=${encodeURIComponent(city)}&appid=${config.API_KEY}&units=${config.UNITS}&lang=${config.LANGUAGE}`;
            
            const response = await fetch(url);
            
            if (!response.ok) {
                throw new Error(`Location "${city}" not found in database`);
            }
            
            const data = await response.json();
            return {
                success: true,
                data: data
            };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    },

    /**
     * Fetch 5-day forecast
     */
    fetchForecast: async (city) => {
        const config = window.APP_CONFIG;
        
        // Use mock data if enabled
        if (config.USE_MOCK_DATA || config.API_KEY === 'YOUR_API_KEY_HERE') {
            return WeatherAPI.getMockForecast(city);
        }
        
        try {
            const url = `${config.API_BASE_URL}/forecast?q=${encodeURIComponent(city)}&appid=${config.API_KEY}&units=${config.UNITS}&lang=${config.LANGUAGE}`;
            
            const response = await fetch(url);
            
            if (!response.ok) {
                throw new Error('Forecast data not available');
            }
            
            const data = await response.json();
            return {
                success: true,
                data: data
            };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    },

    /**
     * Generate mock weather data for demo
     */
    getMockWeather: (city) => {
        const conditions = ['Clear', 'Clouds', 'Rain', 'Drizzle', 'Thunderstorm', 'Snow', 'Mist'];
        const randomCondition = conditions[Math.floor(Math.random() * conditions.length)];
        
        const mockData = {
            name: city,
            sys: { 
                country: 'XX',
                sunrise: Math.floor(Date.now() / 1000) - 7200,
                sunset: Math.floor(Date.now() / 1000) + 36000
            },
            main: {
                temp: Utils.random(5, 35),
                feels_like: Utils.random(5, 35),
                humidity: Utils.random(40, 90),
                pressure: Utils.random(1000, 1030),
                temp_min: Utils.random(5, 25),
                temp_max: Utils.random(25, 35)
            },
            weather: [{
                main: randomCondition,
                description: randomCondition.toLowerCase() + ' conditions',
                icon: '01d'
            }],
            wind: { 
                speed: (Math.random() * 15 + 1).toFixed(1),
                deg: Utils.random(0, 360)
            },
            clouds: {
                all: Utils.random(0, 100)
            },
            visibility: Utils.random(5000, 10000),
            dt: Math.floor(Date.now() / 1000),
            timezone: 0
        };
        
        return {
            success: true,
            data: mockData
        };
    },

    /**
     * Generate mock forecast data
     */
    getMockForecast: (city) => {
        const conditions = ['Clear', 'Clouds', 'Rain', 'Snow'];
        const forecastList = [];
        
        for (let i = 1; i <= 5; i++) {
            const randomCondition = conditions[Math.floor(Math.random() * conditions.length)];
            forecastList.push({
                dt: Math.floor(Date.now() / 1000) + (i * 86400),
                main: {
                    temp: Utils.random(10, 30),
                    temp_min: Utils.random(5, 20),
                    temp_max: Utils.random(20, 35),
                    humidity: Utils.random(40, 90)
                },
                weather: [{
                    main: randomCondition,
                    description: randomCondition.toLowerCase(),
                    icon: '01d'
                }],
                wind: {
                    speed: (Math.random() * 10 + 1).toFixed(1)
                }
            });
        }
        
        return {
            success: true,
            data: {
                city: { name: city },
                list: forecastList
            }
        };
    },

    /**
     * Get weather by coordinates
     */
    fetchWeatherByCoords: async (lat, lon) => {
        const config = window.APP_CONFIG;
        
        if (config.USE_MOCK_DATA) {
            return WeatherAPI.getMockWeather('Current Location');
        }
        
        try {
            const url = `${config.API_BASE_URL}/weather?lat=${lat}&lon=${lon}&appid=${config.API_KEY}&units=${config.UNITS}`;
            
            const response = await fetch(url);
            
            if (!response.ok) {
                throw new Error('Unable to fetch weather for location');
            }
            
            const data = await response.json();
            return {
                success: true,
                data: data
            };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    },

    /**
     * Get user's location
     */
    getUserLocation: () => {
        return new Promise((resolve, reject) => {
            if (!navigator.geolocation) {
                reject(new Error('Geolocation not supported'));
                return;
            }
            
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    resolve({
                        lat: position.coords.latitude,
                        lon: position.coords.longitude
                    });
                },
                (error) => {
                    reject(error);
                }
            );
        });
    }
};

// Export to global scope
window.WeatherAPI = WeatherAPI;
