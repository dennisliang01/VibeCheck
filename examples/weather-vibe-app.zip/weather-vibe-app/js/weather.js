// ============================================
// WEATHER - Main Weather Logic
// ============================================

const Weather = {
    currentCity: null,
    
    /**
     * Initialize weather module
     */
    init: () => {
        Weather.attachEventListeners();
        Weather.loadDefaultCity();
    },

    /**
     * Attach event listeners
     */
    attachEventListeners: () => {
        const searchBtn = document.getElementById('searchBtn');
        const cityInput = document.getElementById('cityInput');
        const quickCityBtns = document.querySelectorAll('.quick-city');

        // Search button click
        searchBtn.addEventListener('click', () => {
            const city = cityInput.value.trim();
            if (city) Weather.search(city);
        });

        // Enter key in search input
        cityInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const city = cityInput.value.trim();
                if (city) Weather.search(city);
            }
        });

        // Quick city buttons
        quickCityBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const city = btn.dataset.city;
                cityInput.value = city;
                Weather.search(city);
            });
        });
    },

    /**
     * Load default city on startup
     */
    loadDefaultCity: () => {
        const config = window.APP_CONFIG;
        const savedCity = Utils.storage.get('lastCity');
        const defaultCity = savedCity || config.DEFAULT_CITY;
        
        document.getElementById('cityInput').value = defaultCity;
        
        // Load after a short delay for better UX
        setTimeout(() => {
            Weather.search(defaultCity);
        }, 500);
    },

    /**
     * Search for weather data
     */
    search: async (city) => {
        Weather.currentCity = city;
        Utils.storage.set('lastCity', city);
        
        // Show loading state
        Weather.showLoading();
        
        try {
            // Fetch current weather
            const weatherResult = await WeatherAPI.fetchWeather(city);
            
            if (!weatherResult.success) {
                Weather.showError(weatherResult.error);
                return;
            }
            
            // Display weather
            Weather.displayWeather(weatherResult.data);
            
            // Fetch and display forecast if enabled
            if (window.APP_CONFIG.ENABLE_FORECAST) {
                const forecastResult = await WeatherAPI.fetchForecast(city);
                if (forecastResult.success) {
                    Weather.displayForecast(forecastResult.data);
                }
            }
            
            Utils.notify(`Weather data loaded for ${city}`, 'success');
            
        } catch (error) {
            Weather.showError(error.message);
        }
    },

    /**
     * Search by geolocation
     */
    searchByLocation: async () => {
        Weather.showLoading();
        
        try {
            const coords = await WeatherAPI.getUserLocation();
            const result = await WeatherAPI.fetchWeatherByCoords(coords.lat, coords.lon);
            
            if (result.success) {
                Weather.displayWeather(result.data);
                document.getElementById('cityInput').value = result.data.name;
            } else {
                Weather.showError(result.error);
            }
        } catch (error) {
            Weather.showError('Unable to get your location. Please search manually.');
        }
    },

    /**
     * Show loading state
     */
    showLoading: () => {
        const weatherDisplay = document.getElementById('weatherDisplay');
        const forecastDisplay = document.getElementById('forecastDisplay');
        
        weatherDisplay.innerHTML = Components.loading();
        forecastDisplay.innerHTML = '';
    },

    /**
     * Show error message
     */
    showError: (message) => {
        const weatherDisplay = document.getElementById('weatherDisplay');
        const forecastDisplay = document.getElementById('forecastDisplay');
        
        weatherDisplay.innerHTML = Components.error(message);
        forecastDisplay.innerHTML = '';
        
        Utils.notify(message, 'error');
    },

    /**
     * Display weather data
     */
    displayWeather: (data) => {
        const weatherDisplay = document.getElementById('weatherDisplay');
        weatherDisplay.innerHTML = Components.weatherDisplay(data);
        
        // Trigger animations
        setTimeout(() => {
            const container = weatherDisplay.querySelector('.weather-container');
            if (container) {
                container.classList.add('active');
            }
        }, 100);
    },

    /**
     * Display forecast data
     */
    displayForecast: (data) => {
        const forecastDisplay = document.getElementById('forecastDisplay');
        forecastDisplay.innerHTML = Components.forecastDisplay(data);
    },

    /**
     * Refresh current weather
     */
    refresh: () => {
        if (Weather.currentCity) {
            Weather.search(Weather.currentCity);
        }
    },

    /**
     * Auto-refresh weather data
     */
    startAutoRefresh: () => {
        const interval = window.APP_CONFIG.UPDATE_INTERVAL;
        
        setInterval(() => {
            if (Weather.currentCity) {
                Weather.refresh();
                console.log('Auto-refreshing weather data...');
            }
        }, interval);
    }
};

// Export to global scope
window.Weather = Weather;
