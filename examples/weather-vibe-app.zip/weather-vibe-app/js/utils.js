// ============================================
// UTILS - Utility Functions
// ============================================

const Utils = {
    /**
     * Format timestamp to readable string
     */
    formatTime: (timestamp, format = 'full') => {
        const date = new Date(timestamp * 1000);
        
        if (format === 'full') {
            return date.toLocaleString('en-US', {
                weekday: 'short',
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        } else if (format === 'time') {
            return date.toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit'
            });
        } else if (format === 'date') {
            return date.toLocaleDateString('en-US', {
                weekday: 'short',
                month: 'short',
                day: 'numeric'
            });
        }
    },

    /**
     * Get current timestamp in ISO format
     */
    getCurrentTimestamp: () => {
        return new Date().toISOString().slice(0, 19).replace('T', ' ');
    },

    /**
     * Calculate uptime
     */
    calculateUptime: (startTime) => {
        const now = Date.now();
        const diff = now - startTime;
        
        const hours = Math.floor(diff / 3600000);
        const minutes = Math.floor((diff % 3600000) / 60000);
        const seconds = Math.floor((diff % 60000) / 1000);
        
        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    },

    /**
     * Get weather icon emoji based on condition
     */
    getWeatherIcon: (condition) => {
        const iconMap = {
            'Clear': '☀️',
            'Clouds': '☁️',
            'Rain': '🌧️',
            'Drizzle': '🌦️',
            'Thunderstorm': '⛈️',
            'Snow': '🌨️',
            'Mist': '🌫️',
            'Fog': '🌫️',
            'Haze': '🌫️',
            'Smoke': '🌫️',
            'Dust': '🌫️',
            'Sand': '🌫️',
            'Ash': '🌫️',
            'Squall': '💨',
            'Tornado': '🌪️'
        };
        
        return iconMap[condition] || '🌡️';
    },

    /**
     * Get stat icon based on type
     */
    getStatIcon: (type) => {
        const iconMap = {
            'humidity': '💧',
            'pressure': '📊',
            'wind': '💨',
            'visibility': '👁️',
            'feels_like': '🌡️',
            'status': '✅'
        };
        
        return iconMap[type] || '📊';
    },

    /**
     * Capitalize first letter
     */
    capitalize: (str) => {
        return str.charAt(0).toUpperCase() + str.slice(1);
    },

    /**
     * Debounce function
     */
    debounce: (func, wait) => {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    /**
     * Generate random number between min and max
     */
    random: (min, max) => {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    },

    /**
     * Convert wind direction degrees to cardinal direction
     */
    degToCompass: (deg) => {
        const val = Math.floor((deg / 22.5) + 0.5);
        const arr = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
        return arr[(val % 16)];
    },

    /**
     * Format temperature
     */
    formatTemp: (temp, unit = 'C') => {
        return `${Math.round(temp)}°${unit}`;
    },

    /**
     * Get temperature color based on value
     */
    getTempColor: (temp) => {
        if (temp < 0) return 'var(--neon-blue)';
        if (temp < 10) return 'var(--neon-purple)';
        if (temp < 20) return 'var(--neon-green)';
        if (temp < 30) return 'var(--neon-yellow)';
        return 'var(--neon-pink)';
    },

    /**
     * Show notification
     */
    notify: (message, type = 'info') => {
        console.log(`[${type.toUpperCase()}] ${message}`);
        // Could be extended with toast notifications
    },

    /**
     * Local storage helpers
     */
    storage: {
        set: (key, value) => {
            try {
                localStorage.setItem(key, JSON.stringify(value));
                return true;
            } catch (e) {
                console.error('Storage error:', e);
                return false;
            }
        },
        
        get: (key) => {
            try {
                const item = localStorage.getItem(key);
                return item ? JSON.parse(item) : null;
            } catch (e) {
                console.error('Storage error:', e);
                return null;
            }
        },
        
        remove: (key) => {
            try {
                localStorage.removeItem(key);
                return true;
            } catch (e) {
                console.error('Storage error:', e);
                return false;
            }
        }
    },

    /**
     * Animation frame helper
     */
    animate: (callback, duration = 1000) => {
        const start = performance.now();
        
        const step = (timestamp) => {
            const progress = Math.min((timestamp - start) / duration, 1);
            callback(progress);
            
            if (progress < 1) {
                requestAnimationFrame(step);
            }
        };
        
        requestAnimationFrame(step);
    },

    /**
     * Parse query parameters
     */
    getQueryParam: (param) => {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(param);
    },

    /**
     * Copy to clipboard
     */
    copyToClipboard: async (text) => {
        try {
            await navigator.clipboard.writeText(text);
            Utils.notify('Copied to clipboard!', 'success');
            return true;
        } catch (e) {
            console.error('Clipboard error:', e);
            return false;
        }
    }
};

// Export to global scope
window.Utils = Utils;
