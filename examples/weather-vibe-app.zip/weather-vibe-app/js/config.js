// ============================================
// CONFIG - Application Configuration
// ============================================

const CONFIG = {
    // API Configuration
    API_KEY: 'YOUR_API_KEY_HERE', // Replace with your OpenWeatherMap API key
    API_BASE_URL: 'https://api.openweathermap.org/data/2.5',
    
    // Default Settings
    DEFAULT_CITY: 'Tokyo',
    UNITS: 'metric', // 'metric' for Celsius, 'imperial' for Fahrenheit
    LANGUAGE: 'en',
    
    // Quick Access Cities
    QUICK_CITIES: [
        'Tokyo',
        'New York',
        'London',
        'Paris',
        'Sydney',
        'Dubai',
        'Singapore',
        'Berlin'
    ],
    
    // UI Settings
    ANIMATION_DELAY: 100,
    PARTICLE_COUNT: 30,
    UPDATE_INTERVAL: 600000, // 10 minutes in milliseconds
    
    // Feature Flags
    ENABLE_FORECAST: true,
    ENABLE_PARTICLES: true,
    ENABLE_AUTO_REFRESH: false,
    USE_MOCK_DATA: true, // Set to true for demo mode without API key
    
    // Mock Data Configuration
    MOCK_DATA_ENABLED: true // Will auto-enable if API_KEY is not set
};

// Check if API key is set, otherwise force mock data
if (CONFIG.API_KEY === 'YOUR_API_KEY_HERE') {
    CONFIG.USE_MOCK_DATA = true;
    console.log('%c⚡ DEMO MODE ACTIVE - Using mock weather data', 'color: #00ff41; font-size: 14px; font-weight: bold;');
    console.log('%cGet a free API key from https://openweathermap.org to use real data', 'color: #00d9ff; font-size: 12px;');
}

// Export config
window.APP_CONFIG = CONFIG;
