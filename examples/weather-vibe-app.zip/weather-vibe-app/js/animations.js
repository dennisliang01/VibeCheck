// ============================================
// ANIMATIONS - Visual Effects & Particles
// ============================================

const Animations = {
    particleCount: 0,
    particlesEnabled: true,
    startTime: Date.now(),

    /**
     * Initialize animations
     */
    init: () => {
        Animations.particlesEnabled = window.APP_CONFIG.ENABLE_PARTICLES;
        
        if (Animations.particlesEnabled) {
            Animations.createParticles();
        }
        
        Animations.updateTimestamp();
        Animations.updateUptime();
        Animations.initScrollAnimations();
    },

    /**
     * Create floating particles
     */
    createParticles: () => {
        const particlesContainer = document.getElementById('particles');
        if (!particlesContainer) return;
        
        const count = window.APP_CONFIG.PARTICLE_COUNT;
        
        for (let i = 0; i < count; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            
            // Random properties
            const size = Math.random() * 4 + 2;
            const startX = Math.random() * window.innerWidth;
            const startY = Math.random() * window.innerHeight;
            const endX = startX + (Math.random() - 0.5) * 200;
            const endY = startY - (Math.random() * 500 + 300);
            const duration = Math.random() * 10 + 5;
            const delay = Math.random() * 5;
            
            // Set CSS variables and styles
            particle.style.cssText = `
                position: absolute;
                width: ${size}px;
                height: ${size}px;
                background: var(--neon-green);
                border-radius: 50%;
                left: ${startX}px;
                top: ${startY}px;
                opacity: 0;
                pointer-events: none;
                --tx: ${endX - startX}px;
                --ty: ${endY - startY}px;
                animation: particleFloat ${duration}s ease-in-out ${delay}s infinite;
                box-shadow: 0 0 ${size * 2}px var(--glow-green);
            `;
            
            particlesContainer.appendChild(particle);
        }
        
        Animations.particleCount = count;
    },

    /**
     * Update timestamp
     */
    updateTimestamp: () => {
        const timestampEl = document.getElementById('timestamp');
        if (!timestampEl) return;
        
        const updateTime = () => {
            const now = new Date();
            const timeString = now.toLocaleString('en-US', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            });
            timestampEl.textContent = timeString.replace(',', ' //');
        };
        
        updateTime();
        setInterval(updateTime, 1000);
    },

    /**
     * Update uptime counter
     */
    updateUptime: () => {
        const uptimeEl = document.getElementById('uptime');
        if (!uptimeEl) return;
        
        const updateUptime = () => {
            uptimeEl.textContent = Utils.calculateUptime(Animations.startTime);
        };
        
        updateUptime();
        setInterval(updateUptime, 1000);
    },

    /**
     * Initialize scroll-based animations
     */
    initScrollAnimations: () => {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                }
            });
        }, observerOptions);
        
        // Observe panels as they're added to DOM
        const observePanels = () => {
            document.querySelectorAll('.panel').forEach(panel => {
                observer.observe(panel);
            });
        };
        
        // Initial observation
        setTimeout(observePanels, 100);
        
        // Re-observe when new panels are added
        const mutationObserver = new MutationObserver(observePanels);
        mutationObserver.observe(document.body, {
            childList: true,
            subtree: true
        });
    },

    /**
     * Glitch effect on element
     */
    glitch: (element, duration = 500) => {
        if (!element) return;
        
        const originalText = element.textContent;
        const chars = '!<>-_\\/[]{}—=+*^?#________';
        let frame = 0;
        const maxFrames = duration / 50;
        
        const interval = setInterval(() => {
            if (frame >= maxFrames) {
                element.textContent = originalText;
                clearInterval(interval);
                return;
            }
            
            element.textContent = originalText
                .split('')
                .map(char => {
                    if (Math.random() > 0.9) {
                        return chars[Math.floor(Math.random() * chars.length)];
                    }
                    return char;
                })
                .join('');
            
            frame++;
        }, 50);
    },

    /**
     * Terminal typing effect
     */
    typeWriter: (element, text, speed = 50) => {
        if (!element) return;
        
        let i = 0;
        element.textContent = '';
        
        const interval = setInterval(() => {
            if (i >= text.length) {
                clearInterval(interval);
                return;
            }
            
            element.textContent += text.charAt(i);
            i++;
        }, speed);
    },

    /**
     * Neon pulse effect
     */
    neonPulse: (element, color = 'var(--neon-green)', duration = 1000) => {
        if (!element) return;
        
        const originalBoxShadow = element.style.boxShadow;
        
        element.style.transition = `box-shadow ${duration / 2}ms ease-in-out`;
        element.style.boxShadow = `0 0 30px ${color}, inset 0 0 20px ${color}`;
        
        setTimeout(() => {
            element.style.boxShadow = originalBoxShadow;
        }, duration / 2);
    },

    /**
     * Add scan line effect to element
     */
    addScanLine: (element) => {
        if (!element) return;
        
        const scanLine = document.createElement('div');
        scanLine.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--neon-blue), transparent);
            animation: scanline 3s linear infinite;
            pointer-events: none;
        `;
        
        element.style.position = 'relative';
        element.style.overflow = 'hidden';
        element.appendChild(scanLine);
    },

    /**
     * Matrix rain effect (optional easter egg)
     */
    matrixRain: (canvas, duration = 5000) => {
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%^&*()';
        const fontSize = 14;
        const columns = canvas.width / fontSize;
        const drops = Array(Math.floor(columns)).fill(1);
        
        const draw = () => {
            ctx.fillStyle = 'rgba(5, 8, 20, 0.05)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            ctx.fillStyle = '#00ff41';
            ctx.font = `${fontSize}px monospace`;
            
            for (let i = 0; i < drops.length; i++) {
                const text = chars[Math.floor(Math.random() * chars.length)];
                ctx.fillText(text, i * fontSize, drops[i] * fontSize);
                
                if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
                    drops[i] = 0;
                }
                drops[i]++;
            }
        };
        
        const interval = setInterval(draw, 33);
        
        setTimeout(() => {
            clearInterval(interval);
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }, duration);
    },

    /**
     * Shake element
     */
    shake: (element, intensity = 5, duration = 500) => {
        if (!element) return;
        
        const originalTransform = element.style.transform;
        const startTime = Date.now();
        
        const animate = () => {
            const elapsed = Date.now() - startTime;
            
            if (elapsed >= duration) {
                element.style.transform = originalTransform;
                return;
            }
            
            const x = (Math.random() - 0.5) * intensity;
            const y = (Math.random() - 0.5) * intensity;
            element.style.transform = `translate(${x}px, ${y}px)`;
            
            requestAnimationFrame(animate);
        };
        
        animate();
    },

    /**
     * Stagger animation for multiple elements
     */
    stagger: (elements, animationClass, delay = 100) => {
        elements.forEach((element, index) => {
            setTimeout(() => {
                element.classList.add(animationClass);
            }, index * delay);
        });
    }
};

// Export to global scope
window.Animations = Animations;
